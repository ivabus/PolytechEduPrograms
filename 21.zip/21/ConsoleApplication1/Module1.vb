﻿Module Module1
    Sub Main()
        Tityl
        Randomize()
        Dim start, language As String
        Console.Write("Choose a language/Выберете язык(ENG/RUS): ")
        language = Console.ReadLine
        Console.WriteLine
        Select Case language
            Case "ENG"
                Console.Write("Start or show rules(S/R): ")
                start = Console.ReadLine
                Console.WriteLine
                Select Case start
                    Case "S"
                        Game(language)
                    Case "R"
                        Console.WriteLine("Card seniority jack (1), queen (2), king (3), ace (4), 5-10. The goal of the game is to be the first to score 21 points. Banker is a computer. The game goes against the computer. At the beginning of the game, players are given one card. The game goes before one of the players scores 21 points and wins, or until he has more than 21 points and the player loses. The first move is for the Computer. If a player does not have enough points to 21, then he can take more cards or give the opponent a move.")
                        Console.Clear
                        Game(language)
                End Select
            Case "RUS"
                Console.Write("Начать или показать правила(S/R): ")
                start = Console.ReadLine()
                Console.WriteLine
                Select Case start
                    Case "S"
                        Game(language)
                    Case "R"
                        Console.WriteLine("Старшинство карт валет(1), дама(2), король(3), туз(4), 5-10. Цель игры - первым набрать 21 очко. Банкир - компьютер. Игра идёт против компьютера. В начале игры игрокам выдаётся по одной карте. Игра идёт до того, как один из игроков наберёт 21 очко и выиграет или до того момента как у него будет больше 21 очка и игрок проиграет. Первый ход пренадляжит Компьютеру. Если у игрока не хватает очков до 21, то он может взять ещё карты ил отдать ход сопернику.")
                        Console.Clear()
                        Game(language)
                        
                End Select
        End Select
        Console.Clear
           
    End Sub
    Sub Tityl
        Console.WriteLine("+----------------------------------------------------------------------+")
        Console.WriteLine("|                                                                      |")
        Console.WriteLine("|                                                                      |")
        Console.WriteLine("|    +-------------------+       +--+                                  |")
        Console.WriteLine("|    |                   |       |  |                                  |")
        Console.WriteLine("|    +----------------+  |       |  |                                  |")
        Console.WriteLine("|                     |  |       |  |                                  |")
        Console.WriteLine("|                     |  |       |  |              +--------------+    |")
        Console.WriteLine("|                     |  |       |  |              |              |    |")
        Console.WriteLine("|                     |  |       |  |              |  +--------+  |    |")
        Console.WriteLine("|    +----------------+  |       |  |              |  |        |  |    |")
        Console.WriteLine("|    |                   |       |  |              |  |        |  |    |")
        Console.WriteLine("|    |  +----------------+       |  |   +-----+    |  |        |  |    |")
        Console.WriteLine("|    |  |                        |  |              |  |        |  |    |")
        Console.WriteLine("|    |  |                        |  |              |  |        |  |    |")
        Console.WriteLine("|    |  |                        |  |              |  |        |  |    |")
        Console.WriteLine("|    |  |                        |  |              |  |        |  |    |")
        Console.WriteLine("|    |  +--------------+         |  |              |  +--------+  |    |")
        Console.WriteLine("|    |                 |         |  |              |              |    |")
        Console.WriteLine("|    +-----------------+         +--+              +--------------+    |")
        Console.WriteLine("|                                                                      |")
        Console.WriteLine("|                                                                      |")
        Console.WriteLine("+----------------------------------------------------------------------+")
    End Sub
    Sub Game(language As String)
        Dim sump, sumk, more, card As Integer
        Dim carden() As String = {"null", "jack", "queen", "king", "ace", "5", "6", "7", "8", "9", "10"}
        Dim cardru() As String = {"ноль", "валет", "дама", "король", "туз", "5", "6", "7", "8", "9", "10"}
        sump = 0
        sumk = 1 + Int(9 * Rnd)
        Do Until sump > 21 Or sump = 21 Or sumk > 21 Or sumk = 21
        Select Case language
            Case "RUS"
                Console.WriteLine("Компьютер: взял карту")
                more = Int(Rnd)
                If more = 1 Then
                    If sumk < 21 Then 
                        Console.WriteLine("Компьютер взял ещё одну карту")
                        sumk = sumk + 1 + Int(Rnd * (UBound(cardru)-1))
                    End If
                End If
                Console.WriteLine("Кол-во очков: " & sump)
                Console.WriteLine("Брать ещё или пропустить (0/1):")
                more = Console.ReadLine()
                Select Case more
                    Case 0
                        card = 1 + Int(Rnd * (UBound(cardru) -1))
                        sump = sump+card
                        Console.WriteLine("Вы взяли карту номиналом: {0} ({1})", card, cardru)
                    Case 1
                        Console.WriteLine
                        Exit Select
                End Select
                
            Case "ENG"
                Console.WriteLine("Computer: picked a card")
                more = Int(Rnd)
                If more = 1 Then
                    If sumk < 21 Then 
                        Console.WriteLine("Computer: picked one more card")
                        sumk = sumk + 1 + Int(Rnd * (UBound(carden)-1))
                    End If
                End If
                Console.WriteLine("You're score is : " & sump)
                Console.WriteLine("Take more or not (0/1):")
                more = Console.ReadLine()
                Select Case more
                    Case 0
                        card = 1 + Int(Rnd * (UBound(cardru) -1))
                        sump = sump + card
                        Console.WriteLine("You take a card that means: {0} ({1})", card, carden)
                    Case 1
                        Console.WriteLine
                        Exit Select
                End Select

        End Select
        loop
        If sump = 21 Then
            Console.WriteLine("Вы победили")
        Elseif sump > 21
            Console.WriteLine("Вы перебрали и проиграли.")
        ElseIf sumk = 21
            Console.WriteLine("Компьютер победил")
        Else 
            Console.WriteLine("Компьютер проиграл")
        End If
    End Sub
End Module
